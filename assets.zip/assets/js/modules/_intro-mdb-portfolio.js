/*!
 * Material Design for Bootstrap 4
 * Version: MDB portfolio 4.1.1
 *
 *
 * Copyright: Material Design for Bootstrap
 * http://mdbootstrap.com/
 *
 * Read the license: http://mdbootstrap.com/license/
 *
 *
 * Documentation: http://mdbootstrap.com/
 *
 * Getting started: http://mdbootstrap.com/getting-started/
 *
 * Tutorials: http://mdbootstrap.com/bootstrap-tutorial/
 *
 * Templates: http://mdbootstrap.com/templates/
 *
 * Support: http://mdbootstrap.com/forums/forum/support/
 *
 * Contact: office@mdbootstrap.com
 *
 * Atribution: Animate CSS, Twitter Bootstrap, Materialize CSS, Normalize CSS, Waves JS, WOW JS, Toastr, Chart.js , Hammer.js
 *
 */


/*

jquery-easing.js
global.js
velocity.min.js
wow.js
scrolling-nav.js
waves.js
preloading.js
card-reveal.js
character-counter.js
toasts.js
smooth-scroll.js
dropdown.js
buttons.js
hammer.js
jquery.hammer.js
sidenav.js
collapsible.js
panel-popuot.js
forms.js
lightbox.js
scrollbar.js
animations.js

*/

